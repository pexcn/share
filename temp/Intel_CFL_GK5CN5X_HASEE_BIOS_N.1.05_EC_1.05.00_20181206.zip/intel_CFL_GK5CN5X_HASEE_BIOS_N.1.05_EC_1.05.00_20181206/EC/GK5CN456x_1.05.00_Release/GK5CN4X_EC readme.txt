*********************************************************************************
                            GK5CN EC RELEASE NOTE

*********************************************************************************
---------------------------------------------------------------------------------
2018/11/27    		     EC Version 1.05.00		      Owner: Mike Tsai
---------------------------------------------------------------------------------
File name: GK5CN4X_10.500
1.fix shutdown will flash at setup menu
2.sync ID-Z solution for drop electric
3.QKey change to "One key internet" for THTF

Note:
     Release Formal version "GK5CN IDX 1.05.00" for Standard
     Release sub version    "GK5CN IDX 1.05.10" for THTF

---------------------------------------------------------------------------------
2018/9/4    		     EC Version 1.04.00		      Owner: Mike Tsai
---------------------------------------------------------------------------------
File name: GK5CN4X_10.400
1.modified GK5CN 6x fan table(v4)
2.modified APC setting
3.cancel hybrid rule
4.sync EC code "speed up AC detect"

---------------------------------------------------------------------------------
2018/8/23    		     EC Version 1.03.00		      Owner: Mike Tsai
---------------------------------------------------------------------------------
File name: GK5CN4X_10.300
1.modified CPU release temperature.
2.modified 6x fan table
3.support TMD table
4.when CPU and GPU temp both <75 deg c, keep fan rotating speed 10s
5.modified 6x APC setting

---------------------------------------------------------------------------------
2018/8/17    		     EC Version 1.02.00		      Owner: Mike Tsai
---------------------------------------------------------------------------------
File name: GK5CN4X_10.200
1.modified office mode basic mode duty setting
2.co-work with BIOS for FN+1 is fan boost function for hasee
3.modified not clear office mode flag when fan boost enable

---------------------------------------------------------------------------------
2018/8/13    		     EC Version 1.01.00		      Owner: Mike Tsai
---------------------------------------------------------------------------------
File name: GK5CN4X_10.100
1.modified GK5CN 6x fan table as GK5CM 6x
2.modified to read GPU temperature and avoid temperature is error
3.disable to monitor and record S5
4.modified fan table protect temperature

---------------------------------------------------------------------------------
2018/8/7    		     EC Version 1.00.00		      Owner: Mike Tsai
---------------------------------------------------------------------------------
File name: GK5CN4X_10.000
1.modified fan table
2.fixed for LID open will sometimes be flash
3.modified to read GPU temperature and avoid temperature is error
4.mofified fan PWM is smooth from high-temperature to lower-temperature
5.add GK5CM 6X APC setting
6.monitor and record S5
7.modifed breathing light bar at S3 mode
8.modified Fn+Insert / Fn+End behavior

---------------------------------------------------------------------------------
2018/7/16    		     EC Version 0.12.00		      Owner: Mike Tsai
---------------------------------------------------------------------------------
File name: GK5CN4X_01.200
1.support MyFan3

---------------------------------------------------------------------------------
2018/7/16    		     EC Version 0.11.00		      Owner: Mike Tsai
---------------------------------------------------------------------------------
File name: GK5CN4X_01.100
1.adjust GPU throttling temperature at gaming office mode
2.fix the issue for sometimes keyboard have no function
3.fix the issue for cannot select gaming/office mode at shell mode

---------------------------------------------------------------------------------
2018/7/13    		     EC Version 0.10.00		      Owner: Mike Tsai
---------------------------------------------------------------------------------
File name: GK5CN4X_01.000
1.support MyFan3
2.changed PROCHOT and GPIO12 10sec when plug out AC
3.check read GPU temperature NG method
4.modified 4x/5x fan table
5.Power Management Template
6.modify default gaming/office mode
7.modified keyboard for ID-X
8.add ctrl+pause is break
9.add alt+PrtSc is SysRq

---------------------------------------------------------------------------------
2018/7/5    		     EC Version 0.03.00		      Owner: Mike Tsai
---------------------------------------------------------------------------------
File name: GK5CN456X_00.300
1.modified Power Management Template (HW APC) - GK5CN4X/5X and GM5CM 6X

---------------------------------------------------------------------------------
2018/6/7    		     EC Version 0.02.00		      Owner: Mike Tsai
---------------------------------------------------------------------------------
File name: GK5CN4X_00.100
1.update ec code "Update 2nd ME KB to add KBID support Everlight Matte LED"
2.change light bar showing mode at s3 state
3.co-work with BIOS for Fn key change for F1~F12 hotkey key
4.fixed sometimes fan boost will auto on after s3 resume 
5.modified for only calibrate battery Zero I at S0
6.code downsizing

---------------------------------------------------------------------------------
2018/5/22    		     EC Version 0.01.00		      Owner: Mike Tsai
---------------------------------------------------------------------------------
File name: GK5CN4X_00.100
1.First release for A SMT
