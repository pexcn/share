open-android-service
===============

公开课android phone和pad客户端共用的服务代码，包括网络协议、数据库和文件服务