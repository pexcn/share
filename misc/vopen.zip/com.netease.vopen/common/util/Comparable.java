package common.util;

public interface Comparable
{
	public int compareTo(Object arg0);
}
