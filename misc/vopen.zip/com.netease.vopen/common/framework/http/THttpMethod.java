package common.framework.http;

public enum THttpMethod {
	GET, POST, PUT, DELETE, HEAD, OPTIONS
}
