package common.pal;

public class SimulateHttp {

}
