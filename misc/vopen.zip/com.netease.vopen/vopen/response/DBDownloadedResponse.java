package vopen.response;


public class DBDownloadedResponse {
	
	private String strCid = "";
	private String strCs_id = "";
	private String strC_name = "";
	private String strC_path = "";
	private String strC_finish = "";
	private String strC_datatime = "";
	private String strC_allsize = "";
	private String strC_download_status = "";
	
	private String strC_ShowId = "";
	private String strC_download_tag = "";
	
	private String strC_downloadLength = "";
	public String getStrC_downloadLength() {
		return strC_downloadLength;
	}
	public void setStrC_downloadLength(String strC_downloadLength) {
		this.strC_downloadLength = strC_downloadLength;
	}
	public String getStrC_percent() {
		return strC_percent;
	}
	public void setStrC_percent(String strC_percent) {
		this.strC_percent = strC_percent;
	}
	public String getStrC_progress_bar() {
		return strC_progress_bar;
	}
	public void setStrC_progress_bar(String strC_progress_bar) {
		this.strC_progress_bar = strC_progress_bar;
	}
	private String strC_percent = "";
	private String strC_progress_bar = "";
	
	public String getStrC_ShowId() {
		return strC_ShowId;
	}
	public void setStrC_ShowId(String strC_ShowId) {
		this.strC_ShowId = strC_ShowId;
	}
	public String getStrC_download_tag() {
		return strC_download_tag;
	}
	public void setStrC_download_tag(String strC_download_tag) {
		this.strC_download_tag = strC_download_tag;
	}
	public String getStrCid() {
		return strCid;
	}
	public void setStrCid(String strCid) {
		this.strCid = strCid;
	}
	public String getStrCs_id() {
		return strCs_id;
	}
	public void setStrCs_id(String strCs_id) {
		this.strCs_id = strCs_id;
	}
	public String getStrC_name() {
		return strC_name;
	}
	public void setStrC_name(String strC_name) {
		this.strC_name = strC_name;
	}
	public String getStrC_path() {
		return strC_path;
	}
	public void setStrC_path(String strC_path) {
		this.strC_path = strC_path;
	}
	public String getStrC_finish() {
		return strC_finish;
	}
	public void setStrC_finish(String strC_finish) {
		this.strC_finish = strC_finish;
	}
	public String getStrC_datatime() {
		return strC_datatime;
	}
	public void setStrC_datatime(String strC_datatime) {
		this.strC_datatime = strC_datatime;
	}
	public String getStrC_allsize() {
		return strC_allsize;
	}
	public void setStrC_allsize(String strC_allsize) {
		this.strC_allsize = strC_allsize;
	}
	public String getStrC_download_status() {
		return strC_download_status;
	}
	public void setStrC_download_status(String strC_download_status) {
		this.strC_download_status = strC_download_status;
	}
}
