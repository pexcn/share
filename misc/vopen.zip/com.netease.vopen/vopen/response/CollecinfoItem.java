package vopen.response;

import vopen.db.DBApi.CollectInfo;

public class CollecinfoItem {
	public CollectInfo mCollectInfo;
	public String mStrPlayRecord;
	
	public CollecinfoItem() {
		// TODO Auto-generated constructor stub
		mCollectInfo = new CollectInfo();
		mStrPlayRecord = "";
	}
}
