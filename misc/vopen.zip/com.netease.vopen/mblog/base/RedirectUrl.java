package mblog.base;

public class RedirectUrl {
	public static final String OAUTH_CALLBACK = "vopenblog://oauth_callback";
	public static final String RENREN_OAUTH_CALLBACK = "http://graph.renren.com/oauth/login_success.html";
	public static final String SINA_OAUTH_CALLBACK = "http://open.163.com";
	
}
