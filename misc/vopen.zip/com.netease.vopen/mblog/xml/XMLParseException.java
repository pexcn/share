package mblog.xml;

public class XMLParseException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public XMLParseException(String msg) {
		super(msg);
	}
}
